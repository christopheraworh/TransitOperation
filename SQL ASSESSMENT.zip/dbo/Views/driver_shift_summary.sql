-- Auto Generated (Do not modify) 8F0F975B4450DBFE7DC78A4D63B20244FC8465017B73B7F4E356BE9F3C49A94E


CREATE VIEW driver_shift_summary AS
WITH ordered AS (
    SELECT
        driver_id,
        shift_id,
        [time],
        action,
        LAG(action) OVER (
            PARTITION BY driver_id, shift_id ORDER BY [time]
        ) AS prev_action,
        LAG([time]) OVER (
            PARTITION BY driver_id, shift_id ORDER BY [time]
        ) AS prev_time
    FROM driver_activity
),

durations AS (
    SELECT
        driver_id,
        shift_id,
        action,
        prev_action,
        DATEDIFF(SECOND, prev_time, [time]) AS duration_seconds
    FROM ordered
    WHERE prev_time IS NOT NULL
)

SELECT
    driver_id,
    shift_id,

    -- count of ON BREAK events
    SUM(CASE WHEN action = 'ON BREAK' THEN 1 ELSE 0 END) AS num_breaks,

    -- time driver was ONLINE = previous state was 'SIGNED ONLINE'
    SUM(CASE WHEN prev_action = 'SIGNED ONLINE' 
             THEN duration_seconds ELSE 0 END) AS total_time_online,

    -- time driver was OFFLINE
    SUM(CASE WHEN prev_action = 'SIGNED OFFLINE' 
             THEN duration_seconds ELSE 0 END) AS total_time_offline,

    -- time driver was ON BREAK
    SUM(CASE WHEN prev_action = 'ON BREAK'
             THEN duration_seconds ELSE 0 END) AS total_time_on_break,

    -- offline while on break (offline + break overlap)
    SUM(CASE WHEN prev_action = 'SIGNED OFFLINE' AND action = 'OFF BREAK'
             THEN duration_seconds ELSE 0 END) AS total_time_on_break_and_offline

FROM durations
GROUP BY driver_id, shift_id;