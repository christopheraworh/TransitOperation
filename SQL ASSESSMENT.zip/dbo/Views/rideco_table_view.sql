-- Auto Generated (Do not modify) 7C431EBDBEDC26E4FB97CEF69AA85E95791903CD5CA2522E5CEE0807FBA11BAC
CREATE VIEW rideco_table_view AS
(select * from driver_activity)