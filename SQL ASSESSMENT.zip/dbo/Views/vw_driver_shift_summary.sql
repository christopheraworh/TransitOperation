-- Auto Generated (Do not modify) 8F0F975B4450DBFE7DC78A4D63B20244FC8465017B73B7F4E356BE9F3C49A94E

-- Creating View
CREATE VIEW vw_driver_shift_summary AS
WITH ordered_events AS (
    -- Add next event information to each row
    SELECT 
        driver_id,
        shift_id,
        time,
        action,
        LEAD(time) OVER (PARTITION BY driver_id, shift_id ORDER BY time) AS next_time,
        LEAD(action) OVER (PARTITION BY driver_id, shift_id ORDER BY time) AS next_action
    FROM driver_activity
),
time_calculations AS (
    -- Calculate duration for each state
    SELECT 
        driver_id,
        shift_id,
        action,
        time,
        next_time,
        next_action,
        DATEDIFF(SECOND, time, next_time) AS duration_seconds
    FROM ordered_events
    WHERE next_time IS NOT NULL  -- Exclude last event in each shift
)
SELECT 
    driver_id,
    shift_id,
    
    -- Count number of breaks
    ISNULL(SUM(CASE WHEN action = 'ON BREAK' THEN 1 ELSE 0 END), 0) AS num_breaks,
    
    -- Total time online (from SIGNED ONLINE until next event)
    ISNULL(SUM(CASE 
        WHEN action = 'SIGNED ONLINE' 
        THEN duration_seconds 
        ELSE 0 
    END), 0) AS total_time_online,
    
    -- Total time offline (from SIGNED OFFLINE until next event)
    ISNULL(SUM(CASE 
        WHEN action = 'SIGNED OFFLINE' 
        THEN duration_seconds 
        ELSE 0 
    END), 0) AS total_time_offline,
    
    -- Total time on break (from ON BREAK until OFF BREAK or other event)
    ISNULL(SUM(CASE 
        WHEN action = 'ON BREAK' 
        THEN duration_seconds 
        ELSE 0 
    END), 0) AS total_time_on_break,
    
    -- Total time offline while on break (ON BREAK followed by SIGNED OFFLINE, until next event)
    ISNULL(SUM(CASE 
        WHEN action = 'ON BREAK' AND next_action = 'SIGNED OFFLINE' 
        THEN duration_seconds 
        ELSE 0 
    END), 0) AS total_time_on_break_and_offline

FROM time_calculations
GROUP BY driver_id, shift_id;