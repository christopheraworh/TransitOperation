CREATE TABLE [dbo].[driver_activity] (

	[driver_id] varchar(20) NULL, 
	[shift_id] varchar(30) NULL, 
	[time] datetime2(0) NULL, 
	[action] varchar(30) NULL
);